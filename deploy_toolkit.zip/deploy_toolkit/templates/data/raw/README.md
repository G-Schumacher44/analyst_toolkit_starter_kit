# Raw Data

Place your input CSV(s) here. The toolkit expects one primary entry file, referenced in:

- `config/run_toolkit_config.yaml` → `pipeline_entry_path`
- Individual module configs may also specify `input_path` overrides.

Recommended naming:
- `synthetic_penguins_v3.5.csv` (example from the resource hub)
- Or a clear, versioned name like `projectname_raw_vYYYYMMDD.csv`

Notes:
- Do not commit data files. This folder is gitignored by default.
- Keep a small sample in a secure share or generate locally if possible.

